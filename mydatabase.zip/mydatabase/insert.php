
<!-- * kainat rasheed code  *-->
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "mydatabase");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Escape user inputs for security
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$blood_group = mysqli_real_escape_string($link, $_REQUEST['blood_group']);
$gender = mysqli_real_escape_string($link, $_REQUEST['gender']);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);
$city = mysqli_real_escape_string($link, $_REQUEST['city']);
$password = mysqli_real_escape_string($link, $_REQUEST['password']);


//$password = mysqli_real_escape_string($link, $_REQUEST['password']);
$sql = "INSERT INTO donation (name,blood_group,gender,email,city,password ) VALUES ('$name','$blood_group','$gender','$email','$city','$password')";
//$sql=  "INSERT INTO donation (blood_group) VALUES ('$blood_group');
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>
