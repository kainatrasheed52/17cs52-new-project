
<!-- 
      * kainat rasheed code *


--><?php 
  //include header file
  include ('include/header.php');
  if(isset($_POST['submit'])){
	  if(isset($_POST['term']) === true){
		  if(isset($_POST['name']) && !empty($_POST['name'])){
			  if(preg_match('/^[A-Za-z\s]+$/',$_POST['name'])){
				  $name = $_POST['name'];
				  
			  }
		   else{ $nameError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>Only lower and upper case and space characterss are alloweds.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';

			  }
	  }else{ $nameError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>please fill the name field.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	  }
	  
	/*   if(isset($_POST['blood_group']) && !empty($_POST['blood_group'])){
		   if(preg_match('/^[A-Za-z\s]+$/',$_POST['blood_group'])){
		$blood_group = $_POST['blood_group'];
	  }else{ $blood_groupError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>select the blood group.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	  }  }else{ $blood_groupError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>please select the city.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	  }
	  		  if(isset($_POST['gender']) && !empty($_POST['gender'])){
		$gender = $_POST['gender'];
	  }else{ $genderError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>select your gender.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	  }*/
	   
	  
	
	  if(isset($_POST['city']) && !empty($_POST['city'])){
			  if(preg_match('/^[A-Za-z\s]+$/',$_POST['city'])){
				  $city = $_POST['city'];
				  
			  }
		   else{ $cityError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>please select the city.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';

			  }
	  }else{ $cityError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>please select the city.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	  }
	/* if(isset($_POST['contact_no']) && !empty($_POST['contact_no'])){
			  if(preg_match('/\d[11]/',$_POST['contact_no'])){
				  $contact = $_POST['contact_no'];
				  
			  }
		   else{ $contactError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>contactnumber must be of 11 numberss .</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';

			  }
	  }else{ $contactError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>please fill the contact.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	  } */
	  
	  
	  
	  if(isset($_POST['password']) && !empty($_POST['password']) && isset($_POST['c_password']) && !empty($_POST['c_password'])){
		  if(strlen($_POST['password'])>=6){
			  if($_POST['password'] == $_POST['c_password']){
				    $password = $_POST['password'];
					}else {
				   $passwordError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>passwords are not same .</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
	  </div> ';
			  }
			  
		  }
	  else{
	  $passwordError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>password must have six characters.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
	  </div> ';}}
	  
	  else{
		  $passwordError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>please fill the password field.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	  }
	  }

  
  
  /* if(isset($_POST['email']) && !empty($_POST['email'])){
	$pattern ='/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';

			  if(preg_match($pattern, $_POST['email'])){
				  $check_email = $_POST['email'];
				  $sql = " SELECT email FROM donor WHERE email='$check_email' ";
				  $result = mysqli_query($connection ,$sql);
				  if(mysqli_num_rows($result)>0){
					  $emailError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>please enter another  email address. this email already exist</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
				  }
				  else{
					  $email = $_POST['email'];
				  }
				  
			  }
	
		   else{ 
		   $emailError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>please enter the valid email address.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
		   </div> ';  }

			  
	  }else{ $emailError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>please enter the email address.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
  }
	  if(isset($name) || isset($blood_group) || isset($gender) || isset($day) || isset($month) || isset($year) || isset($email) || isset($contact) || isset($city) || isset($password)){
		  $DonorDOB = $year."-".$month."-".$day;
	  $sql = "INSERT INTO donor (name,gender,email,city,dob,contact_no,save_life_data,password ) VALUES( '$name','$gender','$email','$city','$DonorDOB','$contact','0','$password')";
	   if(mysqli_query($connection, $sql)) {
		 $submitSucess = '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>data inserted sucessfully.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  </div> ';}
else 
{$submitError = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>data not inserted.try again</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	 
}  
}
  } */
  
  
  
	  
	  
	  
	  
  
  if(isset($_POST['email']) && !empty($_POST['email'])){
		$email = $_POST['email'];
		
  }
  
  else{ $emailError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>input the email address.</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	  }
	
	 if(isset($_POST['blood_group']) && !empty($_POST['blood_group'])){
		$email = $_POST['blood_group'];
		
  }
  
  else{ $blood_groupError = '<div class="alert alert.danger alert-dismissible fade show" role="alert">
  <strong>input the blood group .</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
	  }
  }
  
 
	
	  
 
?>

<style>
	.size{
		min-height: 0px;
		padding: 60px 0 40px 0;
		
	}
	.form-container{
		background-color: #00FF7F;
		border: .5px solid #eee;
		border-radius: 5px;
		padding: 20px 10px 20px 30px;
		-webkit-box-shadow: 0px 2px 5px -2px rgba(89,89,89,0.95);
-moz-box-shadow: 0px 2px 5px -2px rgba(89,89,89,0.95);
box-shadow: 0px 2px 5px -2px rgba(89,89,89,0.95);
	}
	.form-group{
		text-align: left;
	}
	h1{
		color: white;
	}
	h3{
		color: white;
		text-align: center;
	}
	.red-bar{
		width: 25%;
	}
</style>

<div class="container-fluid red-background size">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<h1 class="text-center">Donate</h1>
			<hr class="white-bar">
		</div>
	</div>
</div>
<div class="container size">
	<div class="row">
		<div class="col-md-6 offset-md-3 form-container">
					<h3>SignUp</h3>
					
					<hr class="red-bar">
				
					
					
					
          <!-- Error Messages -->
		  <form action="insert.php" method="post">

					<div class="form-group">
						<label for="fullname">Full Name</label>
						<input type="text" name="name" id="fullname" placeholder="Full Name" required pattern="[A-Za-z/\s]+" title="Only lower and upper case and space" class="form-control">
				<?php 
					if(isset($nameError)) echo $nameError;
					
					
					?>

				<!--
					<div class="form-group">
              <label for="name">Blood Group</label><br>
			   
              <select name="lood_group" id="blood_group"class="form-control demo-default" required>
                <option value="">---Select Your Blood Group---</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="O+">O+</option>
                <option value="O-">O+</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
              </select> 
			
            </div>-->
			
					<div class="form-group">
						<label for="fullname"> blood_group</label>
						<input type="text" name="blood_group" id="blood_group" placeholder="A+ , B+ or else?"  title="Only lower and upper case and space in blood group " class="form-control">
				<?php 
					if(isset($blood_groupError)) echo $blood_groupError;
					
					
					?>

				</div><!--full name-->
					<div class="form-group">
				              <label for="gender">Gender</label><br>
				              		Male<input type="radio" name="gender" id="gender" value="Male" style="margin-left:10px; margin-right:10px;" checked>
				              		Fe-male<input type="radio" name="gender" id="gender" value="Fe-male" style="margin-left:10px;">
				    </div><!--gender-->
					<?php 
					if(isset($genderError)) echo $gendersError;
					
					
					?>
				   
			
				<!--	    <div class="form-group">
					<label for="fullname">Email</label>
						<input type="text" name="email" id="email" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="Please write correct email" class="form-control">
					
					
					</div> -->
					
					
					
					<div class="form-group">
						<label for="fullname"> email</label>
						<input type="text" name="email" id="email" placeholder="xyz123@abc.com"  title="Only lower and upper case and space in email" class="form-control">
				<?php 
					if(isset($emailError)) echo $emailError;
					
					
					?>

				</div><!--full name-->
					
					
				
					<div class="form-group">
              <label for="city">City</label>
              <select name="city" id="city" class="form-control demo-default" required>
	<option value="">-- Select --</option><optgroup title="Azad Jammu and Kashmir (Azad Kashmir)" label="&raquo; Azad Jammu and Kashmir (Azad Kashmir)"></optgroup><option value="Bagh" >Bagh</option><option value="Bhimber" >Bhimber</option><option value="Kotli" >Kotli</option><option value="Mirpur" >Mirpur</option><option value="Muzaffarabad" >Muzaffarabad</option><option value="Neelum" >Neelum</option><option value="Poonch" >Poonch</option><option value="Sudhnati" >Sudhnati</option><optgroup title="Balochistan" label="&raquo; Balochistan"></optgroup><option value="Awaran" >Awaran</option><option value="Barkhan" >Barkhan</option><option value="Bolan" >Bolan</option><option value="Chagai" >Chagai</option><option value="Dera Bugti" >Dera Bugti</option><option value="Gwadar" >Gwadar</option><option value="Jafarabad" >Jafarabad</option><option value="Jhal Magsi" >Jhal Magsi</option><option value="Kalat" >Kalat</option><option value="Kech" >Kech</option><option value="Kharan" >Kharan</option><option value="Khuzdar" >Khuzdar</option><option value="Kohlu" >Kohlu</option><option value="Lasbela" >Lasbela</option><option value="Loralai" >Loralai</option><option value="Mastung" >Mastung</option><option value="Musakhel" >Musakhel</option><option value="Naseerabad" >Naseerabad</option><option value="Nushki" >Nushki</option><option value="Panjgur" >Panjgur</option><option value="Pishin" >Pishin</option><option value="Qilla Abdullah" >Qilla Abdullah</option><option value="Qilla Saifullah" >Qilla Saifullah</option><option value="Quetta" >Quetta</option><option value="Sibi" >Sibi</option><option value="Zhob" >Zhob</option><option value="Ziarat" >Ziarat</option><optgroup title="Federally Administered Tribal Areas (FATA" label="&raquo; Federally Administered Tribal Areas (FATA"></optgroup><option value="Bajaur Agency" >Bajaur Agency</option><option value="Khyber Agency" >Khyber Agency</option><option value="Kurram Agency" >Kurram Agency</option><option value="Mohmand Agency" >Mohmand Agency</option><option value="North Waziristan Agency" >North Waziristan Agency</option><option value="Orakzai Agency" >Orakzai Agency</option><option value="South Waziristan Agency" >South Waziristan Agency</option><optgroup title="Islamabad Capital" label="&raquo; Islamabad Capital"></optgroup><option value="Islamabad" >Islamabad</option><optgroup title="North-West Frontier Province (NWFP)" label="&raquo; North-West Frontier Province (NWFP)"></optgroup><option value="Abbottabad" >Abbottabad</option><option value="Bannu" >Bannu</option><option value="Batagram" >Batagram</option><option value="Buner" >Buner</option><option value="Charsadda" >Charsadda</option><option value="Chitral" >Chitral</option><option value="Dera Ismail Khan" >Dera Ismail Khan</option><option value="Dir Lower" >Dir Lower</option><option value="Dir Upper" >Dir Upper</option><option value="Hangu" >Hangu</option><option value="Haripur" >Haripur</option><option value="Karak" >Karak</option><option value="Kohat" >Kohat</option><option value="Kohistan" >Kohistan</option><option value="Lakki Marwat" >Lakki Marwat</option><option value="Malakand" >Malakand</option><option value="Mansehra" >Mansehra</option><option value="Mardan" >Mardan</option><option value="Nowshera" >Nowshera</option><option value="Peshawar" >Peshawar</option><option value="Shangla" >Shangla</option><option value="Swabi" >Swabi</option><option value="Swat" >Swat</option><option value="Tank" >Tank</option><optgroup title="Punjab" label="&raquo; Punjab"></optgroup><option value="Alipur" >Alipur</option><option value="Attock" >Attock</option><option value="Bahawalnagar" >Bahawalnagar</option><option value="Bahawalpur" >Bahawalpur</option><option value="Bhakkar" >Bhakkar</option><option value="Chakwal" >Chakwal</option><option value="Chiniot" >Chiniot</option><option value="Dera Ghazi Khan" >Dera Ghazi Khan</option><option value="Faisalabad" >Faisalabad</option><option value="Gujranwala" >Gujranwala</option><option value="Gujrat" >Gujrat</option><option value="Hafizabad" >Hafizabad</option><option value="Jhang" >Jhang</option><option value="Jhelum" >Jhelum</option><option value="Kasur" >Kasur</option><option value="Khanewal" >Khanewal</option><option value="Khushab" >Khushab</option><option value="Lahore" >Lahore</option><option value="Layyah" >Layyah</option><option value="Lodhran" >Lodhran</option><option value="Mandi Bahauddin" >Mandi Bahauddin</option><option value="Mianwali" >Mianwali</option><option value="Multan" >Multan</option><option value="Muzaffargarh" >Muzaffargarh</option><option value="Nankana Sahib" >Nankana Sahib</option><option value="Narowal" >Narowal</option><option value="Okara" >Okara</option><option value="Pakpattan" >Pakpattan</option><option value="Rahim Yar Khan" >Rahim Yar Khan</option><option value="Rajanpur" >Rajanpur</option><option value="Rawalpindi" >Rawalpindi</option><option value="Sahiwal" >Sahiwal</option><option value="Sargodha" >Sargodha</option><option value="Sheikhupura" >Sheikhupura</option><option value="Shekhupura" >Shekhupura</option><option value="Sialkot" >Sialkot</option><option value="Toba Tek Singh" >Toba Tek Singh</option><option value="Vehari" >Vehari</option><optgroup title="Sindh" label="&raquo; Sindh"></optgroup><option value="Badin" >Badin</option><option value="Dadu" >Dadu</option><option value="Ghotki" >Ghotki</option><option value="Hyderabad" >Hyderabad</option><option value="Jacobabad" >Jacobabad</option><option value="Jamshoro" >Jamshoro</option><option value="Karachi" >Karachi</option><option value="Kashmore" >Kashmore</option><option value="Khairpur" >Khairpur</option><option value="Larkana" >Larkana</option><option value="Matiari" >Matiari</option><option value="Mirpur Khas" >Mirpur Khas</option><option value="Naushahro Feroze" >Naushahro Feroze</option><option value="Nawabshah" >Nawabshah</option><option value="Qambar Shahdadkot" >Qambar Shahdadkot</option><option value="Sanghar" >Sanghar</option><option value="Shikarpur" >Shikarpur</option><option value="Sukkur" >Sukkur</option><option value="Tando Allahyar" >Tando Allahyar</option><option value="Tando Muhammad Khan" >Tando Muhammad Khan</option><option value="Tharparkar" >Tharparkar</option><option value="Thatta" >Thatta</option><option value="Umerkot" >Umerkot</option></select>
            </div><!--city end-->
			<?php 
					if(isset($cityError)) echo $cityError;
					
					
					?>
			
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" name="password" value="" placeholder="Password" class="form-control" required pattern=".{6,}">
            </div><!--End form-group-->
			<?php 
					if(isset($passwordError)) echo $passwordError;
					
					
					?>
			
            <div class="form-group">
              <label for="password">Confirm Password</label>
              <input type="password" name="c_password" value="" placeholder="Confirm Password" class="form-control" required pattern=".{6,}">
            </div><!--End form-group-->
			<?php 
					if(isset($c_passwordError)) echo $c_passwordError;
					
					
					?>
            <div class="form-inline">
              <input type="checkbox" name="term" value="true" required style="margin-left:10px;">
              <span style="margin-left:10px;"><b>I am agree to donate my blood and show my Name, Contact Nos. and E-Mail in Blood donors List</b></span>
            </div><!--End form-group-->
			
					<div class="form-group">
						<button id="submit" name="submit" type="submit" class="btn btn-lg btn-danger center-aligned" style="margin-top: 20px;">SignUp</button>
					</div>
				</form>
		</div>
	</div>
</div>

<?php 
  //include footer file  kainat rasheed code
  include ('include/footer.php');
?>